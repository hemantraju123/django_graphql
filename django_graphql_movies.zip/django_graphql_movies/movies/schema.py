import graphene
from graphene_django.types import DjangoObjectType,ObjectType
from movies.models import post,provider,Actor,Movie

# Create a GraphQL type for the actor model
class ActorType(DjangoObjectType):
    class Meta:
        model = Actor

# Create a GraphQL type for the movie model
class MovieType(DjangoObjectType):
    class Meta:
        model = Movie

class Posttype(DjangoObjectType):
    class Meta:
        model = post

# Create a Query type
# Resolvers connect the queries in the schema to actual actions done by the database.
# As is standard in Django, we interact with our database via models.
class Providertype(DjangoObjectType):
    class Meta:
        model = provider

class Query(ObjectType):
    actor = graphene.Field(ActorType, id=graphene.Int())
    movie = graphene.Field(MovieType, id=graphene.Int())
    post = graphene.Field(Posttype, id=graphene.Int())
    actors = graphene.List(ActorType)
    movies= graphene.List(MovieType)
    posts = graphene.List(Posttype)
    providers = graphene.List(Providertype)
    def resolve_actor(self, info, **kwargs):
        id = kwargs.get('id')

        if id is not None:
            return Actor.objects.get(pk=id)

        return None

    def resolve_movie(self, info, **kwargs):
        id = kwargs.get('id')

        if id is not None:
            return Movie.objects.get(pk=id)

        return None

    def resolve_post(self,info,**kwargs):
        id = kwargs.get('id')

        if id is not None:
            return post.objects.get(pk=id)

        return None
    def resolve_provider(self,info,**kwargs):
        name =kwargs.get

        if name is not None:
            return provider.objects.get(pk=name)
        return None
    def resolve_actors(self, info, **kwargs):
        return Actor.objects.all()

    def resolve_movies(self, info, **kwargs):
        return Movie.objects.all()

    def resolve_posts(self, info, **kwargs):
        return post.objects.all()
    def resolve_providers(self,info, **kwargs):
        return provider.objects.all()
# Create Input Object Types
class ActorInput(graphene.InputObjectType):
    id = graphene.ID()
    name = graphene.String()

class MovieInput(graphene.InputObjectType):
    id = graphene.ID()
    title = graphene.String()
    actors = graphene.List(ActorInput)
    year = graphene.Int()

class PostInput(graphene.InputObjectType):
    id = graphene.ID()
    original_id = graphene.String()
    title = graphene.String()
    body = graphene.String()
    url = graphene.String()
    # created_at = graphene.DateTime()
    created_by = graphene.String()
    status = graphene.Boolean()
    # actors = graphene.List(ActorInput)

class ProviderInput(graphene.InputObjectType):
    name =graphene.String()
    provider_type = graphene.String()
    status = graphene.Boolean()
    _class = graphene.String()

class CreatePost(graphene.Mutation):
    class Arguments:
        input = PostInput(required=True)

    ok = graphene.Boolean()
    post = graphene.Field(Posttype)

    @staticmethod
    def mutate(root, info, input=None):
        ok = True
        post_instance = post(
            id = input.id,
            title=input.title,
            original_id=input.original_id,
            body=input.body,
            created_by=input.created_by,
            url=input.url,
            status=input.status
        )
        post_instance.save()
        return CreatePost(ok=ok, post=post_instance)
# Create mutations for actors

class CreateActor(graphene.Mutation):
    class Arguments:
        input = ActorInput(required=True)

    ok = graphene.Boolean()
    actor = graphene.Field(ActorType)

    @staticmethod
    def mutate(root, info, input=None):
        ok = True
        actor_instance = Actor(name=input.name)
        actor_instance.save()
        return CreateActor(ok=ok, actor=actor_instance)

#Update mutation
class UpdateActor(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)
        input = ActorInput(required=True)

    ok = graphene.Boolean()
    actor = graphene.Field(ActorType)

    @staticmethod
    def mutate(root, info, id, input=None):
        ok = False
        actor_instance = Actor.objects.get(pk=id)
        if actor_instance:
            ok = True
            actor_instance.name = input.name
            actor_instance.save()
            return UpdateActor(ok=ok, actor=actor_instance)
        return UpdateActor(ok=ok, actor=None)

# Create mutations for movies
class CreateMovie(graphene.Mutation):
    class Arguments:
        input = MovieInput(required=True)

    ok = graphene.Boolean()
    movie = graphene.Field(MovieType)

    @staticmethod
    def mutate(root, info, input=None):
        ok = True
        actors = []
        for actor_input in input.actors:
          actor = Actor.objects.get(pk=actor_input.id)
          if actor is None:
            return CreateMovie(ok=False, movie=None)
          actors.append(actor)
        movie_instance = Movie(
          title=input.title,
          year=input.year,
          )
        movie_instance.save()
        movie_instance.actors.set(actors)
        return CreateMovie(ok=ok, movie=movie_instance)

#update mutation
class UpdateMovie(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)
        input = MovieInput(required=True)

    ok = graphene.Boolean()
    movie = graphene.Field(MovieType)

    @staticmethod
    def mutate(root, info, id, input=None):
        ok = False
        movie_instance = Movie.objects.get(pk=id)
        if movie_instance:
            ok = True
            actors = []
            for actor_input in input.actors:
              actor = Actor.objects.get(pk=actor_input.id)
              if actor is None:
                return UpdateMovie(ok=False, movie=None)
              actors.append(actor)
            movie_instance.title=input.title
            movie_instance.year=input.year
            movie_instance.actors.set(actors)
            movie_instance.save()
            return UpdateMovie(ok=ok, movie=movie_instance)
        return UpdateMovie(ok=ok, movie=None)

#CREATE MUTATION FOR PROVIDER
class CreateProvider(graphene.Mutation):
    class Arguments:
        id = graphene.Int(required=True)

    ok = graphene.Boolean()
    provider = graphene.Field(Providertype)

    @staticmethod
    def mutate(root, info, input=None):
        ok = True
        provider_instance =provider(
            name=input.name,
            provider_type=input.provider_type,
            status=input.status,
        )
        provider_instance.save()
        return CreateProvider(ok=ok, provider=provider_instance)

#DELETE MUTATION FOR MOVIE
class DeleteMovie(graphene.Mutation):
    class Arguments:
        id = graphene.ID()

    ok = graphene.Boolean()
    movie = graphene.Field(MovieType)

    @classmethod
    def mutate(cls, root, info, **kwargs):
        obj = Movie.objects.get(pk=kwargs["id"])
        obj.delete()
        return cls(ok=True)

#DELETE MUTATION FOR PROVIDER
class DeleteProvider(graphene.Mutation):
    class Arguments:
        id = graphene.ID()

    ok = graphene.Boolean()
    provider = graphene.Field(Providertype)

    @classmethod
    def mutate(cls, root, info, **kwargs):
        obj = provider.objects.get(pk=kwargs["id"])
        obj.delete()
        return cls(ok=True)


class Mutation(graphene.ObjectType):
    create_actor = CreateActor.Field()
    update_actor = UpdateActor.Field()
    create_movie = CreateMovie.Field()
    update_movie = UpdateMovie.Field()
    create_post = CreatePost.Field()
    create_provider = CreateProvider.Field()
    delete_movie = DeleteMovie.Field()
    delete_provider = DeleteProvider.Field()

#we map the queries and mutations to our application's API. Add this to the end of schema.py
schema = graphene.Schema(query=Query, mutation=Mutation)