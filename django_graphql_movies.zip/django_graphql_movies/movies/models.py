from django.db import models

class Actor(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table ="actor"
        ordering = ('name',)

class Movie(models.Model):
    title = models.CharField(max_length=100)
    actors = models.ManyToManyField(Actor,)
    year = models.IntegerField()

    def __str__(self):
        return self.title

    class Meta:
        db_table = "movie"
        ordering = ('title',)

class post(models.Model):
    original_id = models.CharField(max_length=500)
    title = models.CharField(max_length=2000)
    body = models.CharField(max_length=1000)
    url = models.CharField(max_length=500)
    # created_at = models.DateTimeField()
    created_by = models.CharField(max_length=2000)
    status = models.BooleanField()

    def __str__(self):
        return self.original_id

    class Meta:
        db_table = "post"
        ordering = ('original_id',)

class provider(models.Model):
    name = models.CharField(max_length=100)
    provider_type = models.CharField(max_length=522)
    status = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "provider"
        ordering = ("name",)